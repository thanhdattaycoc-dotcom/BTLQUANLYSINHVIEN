﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTLQUANLYSINHVIEN
{
    public partial class FormQuanLyNhapHoc : System.Windows.Forms.Form
    {
        public FormQuanLyNhapHoc()
        {
            InitializeComponent();
        }
    }
}
